<?php
$keyId = 'rzp_test_HMScfstLe46cmo';
$keySecret = '7rEpJnERsWRbDfKFEuTB15hr';